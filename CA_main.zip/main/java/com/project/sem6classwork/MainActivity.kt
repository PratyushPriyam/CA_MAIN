package com.project.sem6classwork

import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.widget.AppCompatButton

class MainActivity : AppCompatActivity() {
    lateinit var cameraImg: ImageView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)
        cameraImg = findViewById<ImageView>(R.id.cameraImg)
        val imgBtn = findViewById<AppCompatButton>(R.id.imgBtn)

        imgBtn.setOnClickListener {
            var intent: Intent? = null
            if(Build.VERSION.SDK_INT >= 23) {
                intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            }
            else {
            }
            startActivityForResult(intent, 123)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == 123) {
            val ig = data!!.extras!!["data"] as Bitmap
            cameraImg.setImageBitmap(ig)
        }
    }
}